import pieqt
print(pieqt.QApplication)
